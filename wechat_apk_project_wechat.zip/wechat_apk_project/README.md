# 微信 Android APK

This project wraps the supplied HTML prototype in an Android WebView.
The main screen loads `app/src/main/assets/index-9.html` locally, so the APK does not need GitHub Pages or an internet connection for the HTML itself.

## Build

Run `gradle assembleDebug` after Android SDK setup, or use the included GitHub Actions workflow.
